class PublicArt extends HTMLElement {
  // Place attributes as comma-separated list of Strings within the array
  static observedAttributes = ["heading", "year", "address"];

  // Declare internal properties here
  #attributeValues = {
  heading: "",
  year: "",
  address: ""
  };

  constructor() {
    super(); 
  }
  
  connectedCallback() {
    
    console.log("Custom element added to the page.");

    const shadowRoot = this.attachShadow({ mode: "open" });
    shadowRoot.innerHTML = `
    <style>
      /* CSS styles go here */
      :host {
        /* styles of the top-level host element go here */
        container-type: size;
        >.container {
          height: 100%;
          width: 100%;
        }
      }

      .art {
        box-sizing: border-box;
        overflow: hidden;

        border: 1px solid white;
        border-radius: 0.5rem;
        box-shadow: 2px 4px 1rem rgb(0 0 0 / 0.3);

        height: 100%;

        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2cqw;
        position: relative;

        >*:not(img) {
            padding: 0.5rem
        }

        &>.info {
          h2 {
            font-size: clamp(1rem, 4.5cqw, 1.68rem);
            margin: 2cqw 0 0 0;
          }

          p {
            margin: 0;
            font-size: 3cqw;
          }
        }

        @container (min-width: 640px) and (orientation:landscape) {
          display:block;
          &>.info{
            position: absolute;
            top:0;
            left:0;
            color:white;
            background-color: hsla(0, 0%, 0%, 0.65);

            h2 {
                font-size: clamp(1rem, 3.5cqw, 2rem);
                margin: 0.5cqw 0 0 0;
            }

            p {
                margin: 0;
                font-size: 2cqw;
            }
          }
        }

        @container (orientation: portrait) {
          grid-template-columns: 1fr;
          grid-template-rows: 1fr 1fr;

          &>.info {
            h2 {
                font-size: 5cqh;
                margin: 0.5cqw 0 0 0;
            }

            p {
                margin: 0;
                font-size: 3cqh;
            }
          }
        }
      }

      /* styles of elements slotted into custom element */
      ::slotted(img) {
        height: 100%;
        min-height: 100%;
        width: 100%;
        object-fit: cover;
      }
    </style>
    <!-- HTML goes here -->
    <div class="container">
      <div class="art">
    <!-- properties of the custom element can be embeded like this: ${this.#attributeValues} -->
        <slot></slot>
        <div class="info">
          <h2 part="heading">${this.#attributeValues.heading}</h2>
          <p class="year">Year of installation: ${this.#attributeValues.year}</p>
          <p class="address">Find it IRL at: ${this.#attributeValues.address}</p>
        </div>
      </div>
    </div>
    `;
  }

  disconnectedCallback() {
    console.log("Custom element removed from page.");
  }

  connectedMoveCallback() {
    console.log("Custom element moved with moveBefore()");
  }

  adoptedCallback() {
    console.log("Custom element moved to new page.");
  }

  attributeChangedCallback(name, oldValue, newValue) {
      console.log(`The attribute named ${name} has been changed from ${oldValue} to ${newValue}.`);
      this.#attributeValues[name] = newValue;
    }
}

// Register the element
customElements.define("public-art", PublicArt);
