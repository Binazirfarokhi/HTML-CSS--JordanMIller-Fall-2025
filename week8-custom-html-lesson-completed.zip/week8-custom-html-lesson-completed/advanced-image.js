// Use this template to create the JS implementation of new custom elements.
class AdvancedImage extends HTMLElement {
  // Place attributes as comma-separated list of Strings within the array
  static observedAttributes = ["caption-placement", "src", "alt"];
  // Don't have to put other standard attributes like id, class, etc.
  // Declare internal properties here - attribute values will be stored here
  #attributeValues = {
    src: "",
    alt: "",
    "caption-placement": "center"
  };

  constructor() {
    super(); 
  }
  
  connectedCallback() {
    
    console.log("Custom element added to the page.");

    // Shadow DOM: is a hidden document object model for this element
    // Light DOM: this is the HTML elements that we can actually see in the HTML page
    const shadowRoot = this.attachShadow({ mode: "open" });
    shadowRoot.innerHTML = `
    <style>
      /* CSS styles go here */
      :host {
        /* styles of the top-level host element go here */
        box-shadow: 0.1rem 0.2rem 0.5rem rgb(0 0 0 / 0.5);
        display: block;
        width: min-content;
        padding: 1rem;
        border-radius: 0.5rem;
        img {
          border-radius: 0.5rem;
        }
        position: relative;
        .caption-container {
          border: 1px solid black;
          position: absolute;
          bottom: 0;
          left: 0;
          background-color: rgb(255 255 255 / 0.6);
          padding: 0.5rem;

          ${this.#attributeValues["caption-placement"] == "center" ? "bottom: 50%; left: 50%; transform: translate(-50%, 50%);" : ""}

          /* OPTIONAL CHALLENGE: use the same type of logic for caption-placement="corner" */
        }
      }
      
      /* styles of elements slotted into custom element (not part of shadow DOM) */
      ::slotted(p) {
      /* we can't select children of the slotted content; only simple selectors (like tag and class) are allowed. */
        /* background-color: pink; */
      }
    </style>
    <!-- Shadow DOM HTML goes here --> 
    <img src="${this.#attributeValues.src}" alt="${this.#attributeValues.alt}" part="our-image" >
    <!-- properties of the custom element can be embeded like this: ${this.#attributeValues.src} -->
    <div class="caption-container">
      <slot>Slotted Elements will go here</slot>
    </div>
    `;
  }

  disconnectedCallback() {
    console.log("Custom element removed from page.");
  }

  connectedMoveCallback() {
    console.log("Custom element moved with moveBefore()");
  }

  adoptedCallback() {
    console.log("Custom element moved to new page.");
  }

  // When we set a an attribute value (and when the page is first loaded and attribtes are set for the first time) this function is called
  attributeChangedCallback(name, oldValue, newValue) {
      console.log(`The attribute named ${name} has been changed from ${oldValue} to ${newValue}.`);

      // Store the new attribute value in our variable #attributeValues
      this.#attributeValues[name] = newValue;
  }
}

// Register the element
// Tag naming rules: MUST contain a hyphen, start with a lower-case letter 
customElements.define("advanced-image", AdvancedImage);
// Tag will look like <advanced-image>